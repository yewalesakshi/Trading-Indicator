# RSI + BB %B + MA Alignment Strategy (Pine Script v6)

A TradingView strategy that enters trades only when three indicators agree: a moving average trend filter, RSI, and Bollinger Band %B.

## How it works

**Long entry** (fires on the first bar where all conditions become true):
- Close is above the 50 SMA
- RSI(8) is above the oversold level (40)
- BB %B is above the long level (0.5)

**Short entry**:
- Close is below the 50 SMA
- RSI(8) is below the overbought level (60)
- BB %B is below the short level (0.5)

Trades are reversed when the opposite signal fires. An optional session filter for the Indian market (09:15-15:30 IST) is included.

## Default parameters

| Setting | Default |
|---|---|
| MA Length | 50 |
| RSI Length | 8 |
| RSI Overbought / Oversold | 60 / 40 |
| BB Length | 50 |
| BB StdDev Multiplier | 1.0 |
| BB %B Long / Short Level | 0.5 / 0.5 |
| Position size | 100% of equity |

## Usage

1. Open TradingView and launch the Pine Editor.
2. Paste the contents of `rsi_bb_ma_strategy_v6.pine`.
3. Click **Add to chart**.
4. Adjust inputs from the strategy settings panel.

## Alerts

Two alert conditions are included: **Buy Signal Alert** and **Sell Signal Alert**.

## Preview

Add a screenshot to the `images/` folder and uncomment the line below:

<!-- ![Preview](images/chart-preview.png) -->

## Disclaimer

This project is for educational purposes only and is not financial advice. Backtest results do not guarantee future performance. Trade at your own risk.

## License

MIT
